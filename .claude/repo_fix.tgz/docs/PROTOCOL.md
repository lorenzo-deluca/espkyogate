# Bentel KYO Serial Protocol Reference

Reverse-engineered protocol for the Bentel Security KYO alarm panel family,
communicated over RS-232 serial (via MAX3232 level shifter) at **9600 baud,
8 data bits, EVEN parity, 1 stop bit**.

This document covers all models handled by the espkyogate component: KYO4,
KYO8, KYO8G, KYO8W, KYO8GW, KYO32, and KYO32G. Where behavior differs
between models, the variants are noted explicitly.

> **Disclaimer**: This protocol was determined by analyzing serial traffic
> between the panel and the Bentel "Kyo Unit 5.5" programming software
> (x86 version). It is not an official specification. Use at your own risk.

---

## 1. Physical Layer

| Parameter | Value |
|-----------|-------|
| Baud rate | 9600 |
| Data bits | 8 |
| Parity | EVEN |
| Stop bits | 1 |
| Connector | DB9 via MAX3232 TTL-to-RS232 adapter |
| ESP32 pins (typical) | TX=GPIO17, RX=GPIO16 |

The panel's serial port is active whenever the unit is NOT in programming
mode. While Kyo Unit software is connected (programming mode), the serial
port does not respond to external queries.

---

## 2. Framing and General Message Structure

### 2.1 Request (ESP32 -> Panel)

All requests begin with a **command byte** (`0xF0` for reads, `0x0F` for
writes) followed by parameters and a checksum/trailer byte.

There are three message types:

#### Read requests (6 bytes)

```
[0xF0] [ADDR_LO] [ADDR_HI] [LEN] [0x00] [CHK]
```

| Byte | Name | Description |
|------|------|-------------|
| 0 | Command | `0xF0` = read request |
| 1 | ADDR_LO | Low byte of register address |
| 2 | ADDR_HI | High byte of register address |
| 3 | LEN | Length-1 (number of data bytes minus 1). Data bytes returned = `LEN + 1` |
| 4 | Reserved | Always `0x00` |
| 5 | CHK | Checksum (see section 3) |

> **Address byte order**: The two address bytes are transmitted in
> little-endian order (low byte first, high byte second). For example,
> register address `0x009F` is sent as bytes `9F 00`. Throughout this
> document, register "addresses" are the 16-bit value decoded from this
> LE pair. Checksums use the raw byte sum regardless of interpretation.

#### Write requests (command / control writes)

```
[0x0F] [ADDR_LO] [ADDR_HI] [CMD_TYPE] [0x00] [PAYLOAD_LEN] [DATA...] [CHK] [TRAILER]
```

| Byte | Name | Description |
|------|------|-------------|
| 0 | Command | `0x0F` = write request |
| 1 | ADDR_LO | Low byte of register/function address |
| 2 | ADDR_HI | High byte of register/function address |
| 3 | CMD_TYPE | Command sub-type (varies by command) |
| 4 | Reserved | Always `0x00` |
| 5 | PAYLOAD_LEN | Number of data bytes following |
| 6.. | DATA | Command-specific payload |
| N-1 | CHK | Checksum (see section 3) |
| N | TRAILER | Usually `0xFF` |

#### Write requests (raw configuration download)

Used by KyoUnit during configuration download. This format uses the same
6-byte header as read requests, followed by raw data and a data checksum.

```
[0x0F] [ADDR_LO] [ADDR_HI] [LEN] [0x00] [CHK] [DATA...] [DATA_CHK]
```

| Byte | Name | Description |
|------|------|-------------|
| 0 | Command | `0x0F` = raw data write |
| 1 | ADDR_LO | Low byte of register address |
| 2 | ADDR_HI | High byte of register address |
| 3 | LEN | Length-1 (number of data bytes minus 1) |
| 4 | Reserved | Always `0x00` |
| 5 | CHK | Header checksum (same as read requests) |
| 6.. | DATA | `LEN + 1` data bytes |
| N | DATA_CHK | Checksum of DATA bytes (sum & 0xFF) |

### 2.2 Response (Panel -> ESP32)

The panel echoes the original request bytes followed by response data
and a checksum:

```
[ECHO of request (6 bytes)] [DATA...] [CHK]
```

- For read requests, the echo is always the 6-byte request.
- For read requests, the response data length is `LEN + 1`.
- The response data length varies by command.
- The final byte is a checksum over the data bytes (after the echo).

**Important**: Because the UART is half-duplex on a single bus, the
transmitted bytes appear in the receive buffer as an echo. The driver
reads all bytes and the first `N` bytes (where N = request length)
are the echo of the sent command. Actual response data begins at
byte index `N`.

In the code, response bytes are accessed as `Rx[0]` through `Rx[total-1]`,
where `Rx[0..5]` is the echoed request and `Rx[6..]` is the panel's
response data.

### 2.3 Response sizes

| Command | KYO8/4 response | KYO32/32G response |
|---------|------------------|--------------------|
| Get Sensor Status | 12 bytes total | 18 bytes total |
| Get Partition Status | 17 bytes total | 26 bytes total |
| Get Software Version | 19 bytes total | 19 bytes total |

---

## 3. Checksum Algorithms

Three different checksum methods are used depending on the command:

### 3.1 Read Request Checksum

For 6-byte read requests (`F0 ADDR_LO ADDR_HI LEN 00 CHK`), the
checksum is the low byte of the sum of bytes 0 through 4:

```
CHK = (bytes[0] + bytes[1] + bytes[2] + bytes[3] + bytes[4]) & 0xFF
```

This applies to all read requests, including custom configuration reads.
Verified against all known commands and all config register reads observed
in USB captures.

Example: reading zone config at address `0x009F`, length byte `0x3F`
(64 data bytes):
```
F0 + 9F + 00 + 3F + 00 = 0x1CE → CHK = 0xCE
Request: F0 9F 00 3F 00 CE
```

This formula enables constructing read requests to any register address.

### 3.2 Write Command CRC (`calculateCRC`)

Used for arm/disarm partition commands:

```c
byte calculateCRC(byte *cmd, int lcmd) {
    int sum = 0x00;
    for (int i = 0; i <= lcmd; i++)
        sum += cmd[i];
    return (0x203 - sum);
}
```

Sums bytes `cmd[0]` through `cmd[lcmd]` (inclusive), then returns
`0x203 - sum`, truncated to a byte. This is used for the arm/disarm
commands where `lcmd = 8` (summing bytes 0-8, placing result at byte 9).

### 3.3 Simple Additive Checksum (`getChecksum`)

Used for date/time update and zone include/exclude commands:

```c
uint8_t getChecksum(byte *data, int offset, int len) {
    uint8_t ckSum = 0x00;
    for (int i = offset; i < len; i++)
        ckSum += data[i];
    return ckSum;
}
```

Simply sums the payload bytes and truncates to 8 bits.

### 3.4 Response Checksum Validation

The last byte of every panel response is a checksum over all data bytes
after the echo:

```
expected = sum(Rx[echoLen .. totalLen-2]) & 0xFF
actual   = Rx[totalLen-1]
```

---

## 4. Model Detection

### 4.1 Software Version Query

```
TX: F0 00 00 0B 00 FB
```

Read address `0x0000`, length `0x0B` (12 data bytes).

**Response** (19 bytes total): 6-byte echo + 12 ASCII chars + 1 checksum.

The 12 ASCII characters at `Rx[6..17]` contain the firmware identification
string. Known values:

| Firmware string | Model |
|-----------------|-------|
| `KYO32G  x.xx` | KYO 32G |
| `KYO32   x.xx` | KYO 32 (non-G) |
| `KYO8G   x.xx` | KYO 8G |
| `KYO8W   x.xx` | KYO 8W |
| `KYO8    x.xx` | KYO 8 |
| `KYO4    x.xx` | KYO 4 |

Example: `KYO32   1.05` = KYO 32 non-G, firmware version 1.05.

Model detection uses longest-prefix matching: `KYO32G` is checked before
`KYO32`, `KYO8G`/`KYO8W` before `KYO8`, etc.

### 4.2 Fallback Detection (Response Size)

If the version query fails, the model is inferred from the response
size to the sensor status query:
- **18 bytes**: KYO32-series (defaults to KYO_32 non-G)
- **12 bytes**: KYO8-series or KYO4

---

## 5. Read Commands

### 5.1 Get Sensor Status (Realtime Status + Trouble Status)

```
TX: F0 04 F0 0A 00 EE
```

Read address `0xF004` (on-wire bytes `04 F0`), length `0x0A`
(11 data bytes).

#### KYO32/32G Response (18 bytes total)

| Index | Byte | Content |
|-------|------|---------|
| 0-5 | Echo | Request echo |
| 6 | Rx[6] | Zone status: zones 25-32 (bit 0 = zone 25, bit 7 = zone 32) |
| 7 | Rx[7] | Zone status: zones 17-24 |
| 8 | Rx[8] | Zone status: zones 9-16 |
| 9 | Rx[9] | Zone status: zones 1-8 (bit 0 = zone 1, bit 7 = zone 8) |
| 10 | Rx[10] | Zone tamper: zones 25-32 |
| 11 | Rx[11] | Zone tamper: zones 17-24 |
| 12 | Rx[12] | Zone tamper: zones 9-16 |
| 13 | Rx[13] | Zone tamper: zones 1-8 |
| 14 | Rx[14] | Warning flags (see 5.1.1) |
| 15 | Rx[15] | Partition alarm: bit N = partition N+1 in alarm |
| 16 | Rx[16] | Tamper/sabotage flags (see 5.1.2) |
| 17 | Rx[17] | Checksum |

**Zone bit ordering (KYO32)**: Zones are packed in big-endian byte order
but little-endian bit order within each byte. Byte `Rx[6]` holds zones
25-32, `Rx[7]` holds 17-24, `Rx[8]` holds 9-16, `Rx[9]` holds 1-8.
Within each byte, bit 0 is the lowest-numbered zone in that group.

#### KYO8 Response (12 bytes total)

| Index | Byte | Content |
|-------|------|---------|
| 0-5 | Echo | Request echo |
| 6 | Rx[6] | Zone status: zones 1-8 (bit N = zone N+1) |
| 7 | Rx[7] | Zone tamper: zones 1-8 |
| 8 | Rx[8] | Warning flags (see 5.1.1) |
| 9 | Rx[9] | Partition alarm: bit N = partition N+1 |
| 10 | Rx[10] | Tamper/sabotage flags (see 5.1.2) |
| 11 | Rx[11] | Checksum |

#### 5.1.1 Warning Flags

**KYO32/32G** (Rx[14]):

| Bit | Warning |
|-----|---------|
| 0 | Mains power failure (mancanza rete) |
| 1 | BPI missing (scomparsa BPI) |
| 2 | Fuse fault (fusibile) |
| 3 | Low battery (batteria bassa) |
| 4 | Telephone line fault (guasto linea telefonica) |
| 5 | Default codes active (codici default) |
| 6 | Wireless fault |
| 7 | **UNMAPPED** (observed but purpose unknown) |

**KYO8** (Rx[8]):

| Bit | Warning |
|-----|---------|
| 0 | Mains power failure |
| 1 | BPI missing |
| 2 | Fuse fault |
| 3 | Low battery |
| 4 | *(unused)* |
| 5 | Telephone line fault |
| 6 | Default codes active |
| 7 | *(unused)* |

#### 5.1.2 Tamper/Sabotage Flags

**KYO32/32G** (Rx[16]):

| Bit | Sabotage type |
|-----|---------------|
| 0 | **UNMAPPED** |
| 1 | **UNMAPPED** |
| 2 | Zone tamper (sabotaggio zona) |
| 3 | False key (chiave falsa) |
| 4 | BPI tamper |
| 5 | System tamper (sabotaggio sistema) |
| 6 | RF jam detected (sabotaggio jam) |
| 7 | Wireless tamper (sabotaggio wireless) |

**KYO8** (Rx[10]):

| Bit | Sabotage type |
|-----|---------------|
| 0-3 | *(unused)* |
| 4 | Zone tamper |
| 5 | False key |
| 6 | BPI tamper |
| 7 | System tamper |

---

### 5.2 Get Partition Status

This command reads partition arming state, siren status, output status,
bypassed zones, alarm memory, and tamper memory.

**Register addresses differ by model**:

| Model | Address | Command bytes |
|-------|---------|---------------|
| KYO32G / KYO8W | `0x1502` | `F0 02 15 12 00 19` |
| KYO32 (non-G) | `0x14EC` | `F0 EC 14 12 00 02` |
| KYO8/4/8G | `0x0E68` | `F0 68 0E 09 00 6F` |

Read length byte: `0x12` (19 data bytes) for the KYO32-series responders
(KYO32, KYO32G, KYO8W), `0x09` (10 data bytes) for KYO8/4/8G.

Note: despite its 8-zone hardware, the wireless **KYO8W** answers with the
KYO32-format response and reads partition status at the *KYO32G* register
`0x1502`, not the non-G `0x14EC` — hardware-confirmed in #109. The KYO32
non-G register was briefly shared with the G (`0x1502`) after the two commands
were unified, which left non-G panels stuck reporting all partitions disarmed
(#118); the addresses are model-specific and must not be merged again.

**KYO32 non-G is not a single register generation.** A KYO32 M (2006) panel
whose firmware doesn't answer the version query at all (echo only — see §7)
reads back all-zero at `0x14EC` and only has real data at `0x1502`, the
opposite of the fw-1.05 panel from #118 (issue #122). Since the model can't
be told apart in advance in this case, the component treats `0x14EC` as the
default for any panel it classifies as plain `KYO_32`, and falls back to
`0x1502` at runtime the first time a partition-status read comes back with
no partition in any arming state (`rx[6]|rx[7]|rx[8]|rx[9] == 0` — a real
partition is always in exactly one of the four states). Once the fallback
fires, the component keeps using `0x1502` for the rest of that boot.

#### KYO32/32G Response (26 bytes total)

| Index | Byte | Content |
|-------|------|---------|
| 0-5 | Echo | Request echo |
| 6 | Rx[6] | Partitions armed TOTAL: bit N = partition N+1 armed totally |
| 7 | Rx[7] | Partitions armed PARTIAL: bit N = partition N+1 armed partially |
| 8 | Rx[8] | Partitions armed PARTIAL with delay 0 |
| 9 | Rx[9] | Partitions DISARMED: bit N = partition N+1 disarmed |
| 10 | Rx[10] | Siren/system status (bit 5 = siren active) |
| 11 | Rx[11] | *(purpose uncertain)* |
| 12 | Rx[12] | Output (OC/PGM) status: bit N = output N+1 active **(KYO32G only; reads 0xFF on non-G)** |
| 13 | Rx[13] | Bypassed zones 25-32 |
| 14 | Rx[14] | Bypassed zones 17-24 |
| 15 | Rx[15] | Bypassed zones 9-16 |
| 16 | Rx[16] | Bypassed zones 1-8 |
| 17 | Rx[17] | Alarm memory zones 25-32 |
| 18 | Rx[18] | Alarm memory zones 17-24 |
| 19 | Rx[19] | Alarm memory zones 9-16 |
| 20 | Rx[20] | Alarm memory zones 1-8 |
| 21 | Rx[21] | Tamper memory zones 25-32 |
| 22 | Rx[22] | Tamper memory zones 17-24 |
| 23 | Rx[23] | Tamper memory zones 9-16 |
| 24 | Rx[24] | Tamper memory zones 1-8 |
| 25 | Rx[25] | Checksum |

**Siren status** is at `Rx[10]`, bit 5.

**OC output readback (Rx[12])**: On KYO32G, each bit corresponds to one
of the 8 programmable outputs. On KYO32 non-G, this byte always reads
`0xFF` -- the actual output readback register address for non-G models
is unknown. Output activate/deactivate commands still function correctly;
only readback is broken.

**Zone data bit ordering** follows the same convention as sensor status:
bytes are big-endian (Rx[13] = zones 25-32, Rx[16] = zones 1-8), bits
are little-endian within each byte (bit 0 = lowest zone in group).

#### KYO8 Response (17 bytes total)

| Index | Byte | Content |
|-------|------|---------|
| 0-5 | Echo | Request echo |
| 6 | Rx[6] | Partitions armed TOTAL |
| 7 | Rx[7] | Partitions armed PARTIAL |
| 8 | Rx[8] | Partitions armed PARTIAL delay 0 |
| 9 | Rx[9] | Partitions DISARMED |
| 10 | Rx[10] | Siren/system status (bit 5 = siren) |
| 11 | Rx[11] | Bypassed zones 1-8 |
| 12 | Rx[12] | Alarm memory zones 1-8 |
| 13 | Rx[13] | Tamper memory zones 1-8 |
| 14-15 | | *(padding/unknown)* |
| 16 | Rx[16] | Checksum |

---

## 6. Write Commands

### 6.1 Arm/Disarm Partition

```
TX: 0F 00 F0 03 00 02 [TOTAL] [PARTIAL] [PARTIAL_D0] [CRC] FF
```

Total length: 11 bytes.

| Byte | Value | Description |
|------|-------|-------------|
| 0 | `0x0F` | Write command |
| 1-2 | `0x00 0xF0` | Function address |
| 3 | `0x03` | Sub-command: arm |
| 4 | `0x00` | Reserved |
| 5 | `0x02` | Payload length |
| 6 | TOTAL | Bitmask of partitions to arm totally (bit 0 = P1, bit 7 = P8) |
| 7 | PARTIAL | Bitmask of partitions to arm partially |
| 8 | PARTIAL_D0 | Bitmask of partitions to arm partially with delay 0 (night mode) |
| 9 | CRC | `0x203 - sum(cmd[0..8])`, truncated to uint8_t |
| 10 | `0xFF` | Trailer |

The command sets all partitions simultaneously. Each partition's state is
determined by which bitmask it appears in:
- Bit set in TOTAL (byte 6) -> armed away
- Bit set in PARTIAL (byte 7) -> armed home (bypasses Internal zones)
- Bit set in PARTIAL_D0 (byte 8) -> armed night (bypasses Internal zones, no entry delay)
- Bit not set in any mask -> disarmed

To disarm all partitions, send all three masks as `0x00`.

> **Note**: Upstream espkyogate (lorenzo-deluca) always sends byte 8 as `0x00`
> and documents it as "Padding". Our implementation uses byte 8 for partial
> delay 0 arming. This has been verified working on KYO 32M but needs USB
> capture confirmation to definitively prove the panel respects byte 8
> independently (see test checklist item 2.1).

### 6.3 Reset Alarms

```
TX: 0F 05 F0 01 00 05 FF 00 FF
```

Fixed 9-byte command. No variable parameters. Clears alarm memory
for all zones and partitions.

| Byte | Value | Description |
|------|-------|-------------|
| 0 | `0x0F` | Write command |
| 1-2 | `0x05 0xF0` | Function address |
| 3 | `0x01` | Sub-command |
| 4 | `0x00` | Reserved |
| 5 | `0x05` | Payload length |
| 6 | `0xFF` | Reset mask (all zones) |
| 7 | `0x00` | Padding |
| 8 | `0xFF` | Checksum/trailer |

### 6.4 Activate Output

```
TX: 0F 06 F0 01 00 06 [ACTIVATE_MASK] 00 [CHK]
```

Total length: 9 bytes.

| Byte | Value | Description |
|------|-------|-------------|
| 0 | `0x0F` | Write command |
| 1-2 | `0x06 0xF0` | Function address |
| 3 | `0x01` | Sub-command |
| 4 | `0x00` | Reserved |
| 5 | `0x06` | Payload length indicator |
| 6 | MASK | Bitmask of outputs to activate (bit 0 = output 1) |
| 7 | `0x00` | Deactivation mask (zero for activate) |
| 8 | CHK | Same value as byte 6 (MASK) |

To activate output N (1-based): `MASK = 1 << (N - 1)`.

### 6.5 Deactivate Output

```
TX: 0F 06 F0 01 00 06 00 [DEACTIVATE_MASK] [CHK]
```

Total length: 9 bytes.

| Byte | Value | Description |
|------|-------|-------------|
| 6 | `0x00` | Activation mask (zero for deactivate) |
| 7 | MASK | Bitmask of outputs to deactivate (bit 0 = output 1) |
| 8 | CHK | Same value as byte 7 (MASK) |

Bytes 0-5 are identical to activate.

### 6.6 Update Date/Time

```
TX: 0F 03 F0 05 00 07 [DAY] [MONTH] [YEAR] [HOURS] [MINUTES] [SECONDS] [CHK]
```

Total length: 13 bytes.

| Byte | Value | Description |
|------|-------|-------------|
| 0 | `0x0F` | Write command |
| 1-2 | `0x03 0xF0` | Function address |
| 3 | `0x05` | Sub-command |
| 4 | `0x00` | Reserved |
| 5 | `0x07` | Payload length |
| 6 | DAY | Day of month (1-31, decimal, NOT BCD) |
| 7 | MONTH | Month (1-12) |
| 8 | YEAR | Year offset from 2000 (e.g., 25 for 2025) |
| 9 | HOURS | Hours (0-23) |
| 10 | MINUTES | Minutes (0-59) |
| 11 | SECONDS | Seconds (0-59) |
| 12 | CHK | `getChecksum(cmd, 6, 12)` = sum of bytes 6-11 |

### 6.7 Include Zone (Re-enable bypassed zone)

```
TX: 0F 01 F0 07 00 07 00 00 00 00 [Z25-32] [Z17-24] [Z9-16] [Z1-8] [CHK]
```

Total length: 15 bytes.

| Byte | Value | Description |
|------|-------|-------------|
| 0 | `0x0F` | Write command |
| 1-2 | `0x01 0xF0` | Function address |
| 3 | `0x07` | Sub-command |
| 4 | `0x00` | Reserved |
| 5 | `0x07` | Payload length |
| 6-9 | `0x00` | Exclude bitmask (zero for include) |
| 10 | Z25-32 | Include bitmask: zones 25-32 |
| 11 | Z17-24 | Include bitmask: zones 17-24 |
| 12 | Z9-16 | Include bitmask: zones 9-16 |
| 13 | Z1-8 | Include bitmask: zones 1-8 |
| 14 | CHK | Equals the single non-zero bitmask byte |

To include zone N: set the appropriate bit in the correct byte.
Zone mapping to bytes:

| Zone range | Byte index |
|------------|------------|
| 1-8 | 13 |
| 9-16 | 12 |
| 17-24 | 11 |
| 25-32 | 10 |

Within each byte: `bit = 1 << ((zone - base) % 8)` where base is
the lowest zone number for that byte group.

### 6.8 Exclude Zone (Bypass zone)

```
TX: 0F 01 F0 07 00 07 [Z25-32] [Z17-24] [Z9-16] [Z1-8] 00 00 00 00 [CHK]
```

Total length: 15 bytes. Same structure as Include but the bitmask
occupies bytes 6-9 (exclude fields) instead of bytes 10-13 (include
fields).

| Byte | Value | Description |
|------|-------|-------------|
| 6 | Z25-32 | Exclude bitmask: zones 25-32 |
| 7 | Z17-24 | Exclude bitmask: zones 17-24 |
| 8 | Z9-16 | Exclude bitmask: zones 9-16 |
| 9 | Z1-8 | Exclude bitmask: zones 1-8 |
| 10-13 | `0x00` | Include bitmask (zero for exclude) |
| 14 | CHK | Equals the single non-zero bitmask byte |

---

## 7. Register Address Summary

| Address | Length | Command Name | Models |
|---------|--------|--------------|--------|
| `0x0000` | `0x0B` | Software Version | All |
| `0xF004` | `0x0A` | Sensor Status (zones + warnings + tampers) | All |
| `0x1502` | `0x12` | Partition Status | KYO32G |
| `0x14EC` | `0x12` | Partition Status | KYO32 (non-G) |
| `0x0E68` | `0x09` | Partition Status | KYO8/4/8G/8W |

### Write function addresses:

| Addr bytes | Function |
|------------|----------|
| `00 F0` | Arm / Disarm partition |
| `05 F0` | Reset alarms |
| `06 F0` | Activate / Deactivate output |
| `03 F0` | Update date/time |
| `01 F0` | Include / Exclude zone |

---

## 8. Polling Architecture

### 8.1 Non-Blocking Serial I/O

The component uses a non-blocking async state machine for serial
communication. `update()` (called every 500ms) sends a command, and
`loop()` collects response bytes incrementally without blocking. Response
completion is detected by inter-byte silence (10ms with no new bytes
after receiving data beyond the echo).

### 8.2 Normal Polling Cycle

Each `update()` cycle sends the sensor status query. When the sensor
response is received in `loop()`, the partition status query is chained
immediately. This means both queries complete within a single 500ms
cycle, giving a full status refresh every 500ms.

Response caching (`memcmp` against previous response bytes) skips
parsing and publishing when the panel state has not changed.

### 8.3 Configuration Read Phase

After model detection, the component reads panel configuration
registers once (one step per `update()` cycle to avoid blocking):

| Step | Register | Content | Timing |
|------|----------|---------|--------|
| 1 | 0x009F, 0x00DF | Zone configuration (type, enrollment, area) | ~300ms |
| 2 | 0x2E00-0x2FC0 | Zone names (16 ASCII bytes each) | ~300ms |
| 3 | 0xC045-0xC0A4 | Zone ESN (one zone per cycle) | ~1.5s × 32 |
| 4 | 0x3280-0x3340 | Output names | ~300ms |
| 5 | 0x016F | Partition timers (entry/exit/siren) | ~300ms |
| 6 | 0xC0B1-0xC0DE | Keyfob ESN (one keyfob per cycle) | ~1.5s × 16 |
| 7 | 0x3180-0x3240 | Keyfob names | ~300ms |
| 8 | — | Publish all text sensors | instant |

Steps 3 and 6 read one EEPROM slot per cycle (see section 10.16) to
avoid blocking the main loop for 48+ seconds. Normal sensor/partition
polling is suspended during the config read phase.

### 8.4 Communication Health

Communication health is tracked with exponential backoff:
- Resets to 0 consecutive failures on each successful response.
- Increments on each failed response.
- After 3 consecutive failures, the communication sensor publishes
  `false` and polling backs off exponentially (2s, 4s, 8s, 16s, 32s).
- On recovery, a forced full publish ensures all sensors are updated.

---

## 9. KYO32 vs KYO32G Differences

| Feature | KYO32G | KYO32 (non-G) |
|---------|--------|----------------|
| Firmware prefix | `KYO32G` | `KYO32` |
| Partition status address | `0x1502` | `0x14EC` usually, `0x1502` on some units (see below) |
| Max programmable outputs | 8 | 3 |
| Output readback (Rx[12]) | Valid bitmask | Always `0xFF` |
| Sensor status response | 18 bytes | 18 bytes |
| Partition status response | 26 bytes | 26 bytes |
| Wireless support | Yes | Varies by sub-model |
| Programmable name tables | Low range (see below) | `0x2BA0`-`0x347F` |

The non-G model is the older generation. The KYO 32M (marketing name)
is a non-G KYO32 that supports wireless zones. Its firmware string is
`KYO32   x.xx` (same as non-G). Most units confirmed so far (fw 1.05,
issue #118) use the KYO32 (non-G) register address `0x14EC` for partition
status, but a KYO32 M from 2006 (issue #122) — old enough that it doesn't
answer the version query at all — only has data at `0x1502` instead. See
§5.2 for the runtime fallback that handles both without needing to tell
the two apart in advance.

### 9.1 KYO32G name table relocation

On KYO32G the user-programmed name tables are stored in a lower address range
than on non-G models. The non-G addresses (`0x2BA0`-`0x347F`) still respond on
KYO32G but return a built-in **default label ROM** (factory names in the panel's
configured language), not the user-edited labels. The actual programmable names
live here:

| Table | KYO32G base | Count | non-G base |
|-------|-------------|-------|------------|
| Partition names | `0x1750` | 8 | `0x2BA0` |
| Keypad names | `0x17D0` | 8 | `0x2C20` |
| Reader names | `0x1850` | 16 | `0x2CA0` |
| Expander names | `0x1950` | 6 | `0x2DA0` |
| Zone names | `0x19B0` | 32 | `0x2E00` |
| Code names | `0x1BB0` | 24 | `0x3000` |
| Keyfob names | `0x1D30` | 16 | `0x3180` |
| Output names | `0x1E30` | 16 | `0x3280` |
| Phone number names | `0x1F30` | 8 | `0x3380` |

Each entry is 16 ASCII bytes, space-padded, read 4 per 64-byte request. The bases
are not a single uniform offset from the non-G map, so each table is mapped
individually. The component selects these addresses when the detected model is
KYO32G (see `read_*_names_()` in `bentel_kyo.cpp`).

### 9.2 KYO8 name table layout (firmware 2.04)

The KYO4/8/8G family uses a third, distinct label-table layout, mapped via an
on-device memory scan on a KYO8 2.04 (issue #113). The non-G addresses respond
but land on the LCD menu-string ROM (`0x30C0`-`0x324F`) or unrelated data. The
user-label table is one contiguous block at `0x3250`-`0x37EF`, in a different
entity order than the non-G map:

| Table | KYO8 base | Count | Default labels |
|-------|-----------|-------|----------------|
| Zone names | `0x3250` | 8 | `Zona N` |
| Partition (area) names | `0x32D0` | 4 | `Area 0N` |
| Keypad names | `0x3310` | 8 | `Tastiera 0N` |
| Reader names | `0x3390` | 16 | `Lettore NN` |
| Code names | `0x3490` | 24 | `Codice N` |
| Keyfob (digital key) names | `0x3610` | 16 | `Attivatore N` |
| Output names | `0x3710` | 5 | `Uscita N` |
| Phone number names | `0x3760` | 8 | `Numero N` |

The table ends with a single generic `Chiave` slot at `0x37E0` followed by ROM
date-format strings (`GMA`/`MGA`/`AMG`). Entity counts follow the KYO8 hardware
(4 partitions, 5 outputs); "attivatore" is Bentel's term for the digital keys
presented to readers, matching the non-G "digital key names" table by relative
position and count.

Other KYO8 2.04 findings from the same scan:

- The KYO32 fixed registers do not apply: `0x01E6` (panel mode) reads `00 00`,
  `0x1503` (status flags) reads ASCII text, `0x016F` (partition timers) reads a
  6-byte-record index table, and `0x01DF`-`0x021E` is all zeros.
- The area timers (the keypad's Times -> Areas menu, `Tempi -> Aree`) live at
  `0x00DC`, immediately after the zone-config block. Layout pinned by
  differential captures (single-byte flips for exit delay, siren duration and
  patrol time) and cross-checked field by field against the Bentel Security
  Suite 5.5.4 "Areas" page:

  | Address | Field | Unit |
  |---------|-------|------|
  | `0x00DC`-`0x00DF` | Exit delay, partitions 1-4 | seconds |
  | `0x00E0`-`0x00E3` | Entry delay, partitions 1-4 | seconds |
  | `0x00E4`-`0x00E7` | Scheduler advance-warning time, partitions 1-4 | minutes |
  | `0x00E8`-`0x00EB` | And-Zone time, partitions 1-4 | 15-second steps |
  | `0x00EC`-`0x00EF` | And-Code time, partitions 1-4 | seconds |
  | `0x00F8` | Patrol time (global) | minutes |
  | `0x00F9` | Handsfree/speakerphone timeout (global) | — |
  | `0x00FA` | Alarm-cycle/siren duration (global, 0-63; 0 = siren outputs never fire) | minutes |
  | `0x00FF`-`0x0103` | Output monostable ON time, outputs 1-5 | seconds |
  | `0x0104`-`0x0108` | Output monostable OFF time, outputs 1-5 | seconds |
  | `0x0112` | Dial attempts | count |
  | `0x0119` | Remote-assistance ring count | count |

  Original labels in the (Italian-only) Suite UI: `T. Uscita`, `T. Ingresso`,
  `T. Preavviso`, `T. And Zone`, `T. Cod And`, `Tempo di Ronda`,
  `Timeout Vivavoce`, `Tempo di Allarme`, `N. Squilli Teleassistenza`. The
  telephony fields were pinned by a batched differential (two fields changed
  with distinct values, one scan): handsfree timeout 3→5 flipped `0x00F9`,
  ring count 3→4 flipped `0x0119`; `0x0112` matches the configured dial
  attempts, and the repeating `1E 1E 03 03 03` pattern at `0x00FF`-`0x0108`
  matches the outputs' monostable ON/OFF times (5 slots, the KYO8 panel
  exposes 3: outputs 1-2 = 30s/30s, output 3 = 3s/3s, slots 4-5 at defaults).

  The last unidentified run, `0x00F0`-`0x00F7` (`1E` x8), matches no Suite
  field on KYO8. An earlier guess (exit/entry slots for partitions 5-8) was
  **ruled out** by a full config scan of a KYO32G 2.13: that model stores all
  eight areas' timers together at `0x016F` (areas 5-8 included, read and
  correct), and its 32-zone config table fills `0x009F`-`0x011E`, so on the
  KYO32 family `0x00F0`-`0x00F7` is zone-config data, not timers. The KYO8
  compact timer block is therefore its own layout; these 8 bytes are most
  likely two further per-area (1-4) timer types at their 30s default, still
  unmapped for lack of a Suite field to flip.

- The zone-config block at `0x009F` starts with a 4-byte header on KYO8: zone
  records begin at `0x00A3` (validated: with the shift, zones land in the areas
  configured on the panel; without it zone 1 reads area `0x00`). Record layout,
  confirmed by Suite-vs-scan differentials:

  | Offset | Field | Values |
  |--------|-------|--------|
  | +0 | Type + balance | Low bits: `0x00` Instant, `0x01` Delayed, `0x02` Path. High bits: wiring/balance, Normally Closed = `0x00`, Normally Open = `+0x08` (differential: NO→NC flipped `08`→`00`) |
  | +1 | Attribute bitmask | Internal (`Interna`) = `0x20` (differential: toggling it flipped `00`→`20`); `0x00` = no attributes set. Previously suspected to be an enrolled flag — it is not |
  | +2 | Area mask | `0x01` = area 1 … `0x08` = area 4 |
  | +3 | Alarm cycles | 0-14; `0x0F` = repetitive/unlimited (`Cicli` in the Suite) |

  Note the layout differs from KYO32 (section 10.1), where +1 is the
  wireless-enrolled flag and +3 is the attribute byte.
- The `0xC045`/`0xC0B1` ESN windows read unrelated config data on KYO8 — a panel
  with no wireless receiver and zero keyfobs returned non-empty "serials", with
  area-timer bytes visible in the higher slots. The wireless-enrollment storage,
  if this hardware variant has one, has not been located.
- Entering the installer menu on the keypad makes the panel stop answering the
  serial bus entirely (polls time out until the menu is exited), so programming
  mode cannot be detected via a register read on this firmware — the
  communication-status sensor is the only observable signal.
- Verification technique: the official Bentel Security Suite can be run against
  the panel *through* the ESP32 using a TCP-serial passthrough (e.g. the
  esphome-stream-server external component with the UART left untouched while no
  TCP client is connected), disabling this component's polling switch for the
  session. A virtual COM port mapped to the ESP32's TCP port lets the Suite read
  and write the full panel configuration with no B-Mod cable, enabling
  Suite-vs-memory-scan differentials for any register.

### 9.3 KYO8 2.04 memory map (full-sweep reference)

A full sweep of the readable address ranges on a KYO8 2.04 (same range set used
for the KYO32G, ~1 minute with normal polling still running) surfaced these
regions beyond the ones mapped above:

| Range | Content |
|-------|---------|
| `0x0000`-`0x003F` | **Not readable** — the panel answers the `0xF0` read with a short 19-byte reply instead of a full response. The same window reads normally on KYO32G 2.13 |
| `0x0040`-`0x00A2` | 9-byte records with `0x0F` at offset 0, back-to-back (11 slots; the last one overlaps the 4-byte zone-config header at `0x009F`) — plausibly per-code config records; unmapped |
| `0x08BB`-`0x09FF` | Sequential 3-byte slot table, first byte an index incrementing `0x01`, `0x02`, … (past `0x6B` where the sweep window ends); purpose unknown |
| `0x1490`-`0x15FF` (approx.) | Second copy of the code names (`Codice 4` observed at `0x14C0`, implying `Codice 1` at `0x1490`) — distinct from the `0x3490` table the component reads; which copy the keypad uses is unknown |
| `0x2BA0`-`~0x2E05` | Event log — timestamped records (`DD MM YY HH mm` + event code) matching the keypad's `Registro Eventi`. Note this address is the partition-name table on KYO32 non-G (section 10.10) and string ROM on KYO32G (section 10.28) |
| `0x2E60`-`0x2E8F` | Misc telephony/config bytes, including an access PIN stored as plain ASCII around `0x2E76` |
| `0x2E90`-`0x2EA6` | DTMF/keypad character table (`, * # ABCDEF`) |
| `0x2EA7`-`0x30BB` | Dense binary tables, unmapped |
| `0x30C0`-`0x381F` | LCD menu strings followed by the user-label tables of section 9.2 |

**Privacy note for scan logs:** a KYO8 sweep captures personal data — event-log
timestamps, code and phone-book names, an ASCII PIN near `0x2E76` and BCD phone
digits near `0x0109`. Redact these regions before attaching scan output to a
public issue.

---

## 10. Configuration Register Map

The panel's entire configuration is stored in a 64K address space readable
via the `0xF0` read command (section 2.1). The following register addresses
were identified by analyzing USB captures of KyoUnit upload (read) and
download (write) sessions.

All addresses are for **KYO32/KYO32M** (non-G). KYO32G addresses may differ
for some registers (notably partition status uses `0x1502` instead of `0x14EC`).

Wire bytes shown below match actual USB captures. Addresses are 16-bit
values decoded from the little-endian byte pair in bytes 1-2 of the command.

### 10.1 Zone Configuration (0x009F-0x011E)

128 bytes total: 4 bytes per zone, 32 zones.

```
Address range: 0x009F - 0x011E
Read as:       F0 9F 00 3F 00 CE (zones 1-16, 64 bytes)
               F0 DF 00 3F 00 0E (zones 17-32, 64 bytes)
```

Each 4-byte zone record:

| Offset | Name | Description |
|--------|------|-------------|
| +0 | Type/Balance | Zone type in lower bits, balance mode in upper bits |
| +1 | Enrolled | `0x01` = sensor enrolled, `0x00` = not enrolled |
| +2 | Area | Area bitmask (`0x01`=area 1, `0x02`=area 2, `0x04`=area 3, etc.) |
| +3 | Attributes | Zone attributes (observed: `0x0F` for all zones) |

**Zone type** (byte 0 lower bits):

| Value | KyoUnit name | Description |
|-------|--------------|-------------|
| `0x00` | Instant | Triggers alarm immediately |
| `0x01` | Delayed | Follows entry delay if Path zone triggered first |
| `0x02` | Path | Entry/exit path zone with configurable delay |
| `0x18` | *(unconfigured)* | Factory default for unused zone slots |

> **Verification**: Zone type values were confirmed by comparing register
> data before and after known KyoUnit changes: Zone 3 changed from Delayed
> (0x01) to Path (0x02), zones 5-6 changed from Instant (0x00) to Delayed
> (0x01). The before/after register dumps match the expected values exactly.

Example from a KYO32M (after configuration):
```
Zone  1 (configured):      00 01 01 0F → Instant, enrolled, area 1
Zone  2 (configured):      02 01 01 0F → Path, enrolled, area 1
Zone  3 (configured):      02 01 02 0F → Path, enrolled, area 2
Zone  4 (configured):      00 01 02 0F → Instant, enrolled, area 2
Zone  5 (configured):      01 01 02 0F → Delayed, enrolled, area 2
Zone  6 (configured):      01 01 02 0F → Delayed, enrolled, area 2
Zone  7 (configured):      00 01 04 0F → Instant, enrolled, area 3
Zone 12 (unconfigured):    00 00 01 0F → Instant, not enrolled, area 1
Zone 17 (unconfigured):    18 00 01 0F → Factory default
```

### 10.2 Zone Names (0x2E00-0x2FFF)

512 bytes total: 16 ASCII bytes per zone name, 32 zones, space-padded.

```
Address range: 0x2E00 - 0x2FFF
Read as:       F0 00 2E 3F 00 5D (zones 1-4)
               F0 40 2E 3F 00 9D (zones 5-8)
               F0 80 2E 3F 00 DD (zones 9-12)
               F0 C0 2E 3F 00 1D (zones 13-16)
               F0 00 2F 3F 00 5E (zones 17-20)
               F0 40 2F 3F 00 9E (zones 21-24)
               F0 80 2F 3F 00 DE (zones 25-28)
               F0 C0 2F 3F 00 1E (zones 29-32)
```

Each read returns 64 data bytes (4 zone names × 16 bytes). Default names
follow the pattern `Zone NN` (e.g., `Zone 12          `).

### 10.3 User Access Codes (0x019E / 0x01B4)

> **Credential region.** `memory_scan` masks these bytes as `XX`. Do not
> unmask them when sharing a dump — they are the codes that disarm the panel.
> KYO8 does not use this table: it keeps its code as ASCII digits inside
> `0x2E60`-`0x2E8F` (9.3), which the scan masks instead on that family.

One 3-byte record per code slot, holding the code as **BCD digits padded with
nibble `0xF`**. Bentel codes are 4-6 digits, so the padding length varies with
the code:

| Bytes | Code | Digits | Padding |
|-------|------|--------|---------|
| `12 34 56` | `123456` | 6 | none |
| `12 34 5F` | `12345` | 5 | one `F` |
| `12 34 FF` | `1234` | 4 | two `F` |

Illustrative values only — never quote real records from a dump.

A slot the installer never changed reads as its own slot number, zero-padded to
four digits: slot 6 reads `00 06 FF` = `0006`, slot 24 reads `00 24 FF` = `0024`.
That is the factory default, not a placeholder.

Base address differs by firmware generation, the same 22-byte shift seen at the
landmark `26 66 92 C0 FA FF FF` (`0x018E` non-G, `0x01A4` on the G):

```
KYO32 1.05 (non-G):  0x019E - 0x01E5
KYO32G 2.13:         0x01B4 - 0x01FE
```

> **Previously documented as "Zone Enrollment"** — 3-byte records read as two
> ESN bytes plus an `0xFF` marker, with unenrolled zones showing their zone
> number. The record shape fits, the content does not. Two observations rule it
> out: the trailing `0xF` nibbles are *variable-length padding* that tracks the
> digit count, not a fixed marker; and on a KYO32G with no wireless zones at all
> (every zone record carries attribute byte `0x00`, i.e. `ViaRadio` off) the
> first record held the panel's actual 6-digit access code, confirmed against the
> keypad. A wireless-enrollment table on that panel would be empty.
>
> Wireless ESNs are stored separately at `0xC045` (10.15), which is what the
> component actually reads.

### 10.4 Partition Configuration (0x01E9-0x0228)

64 bytes total: 10 bytes per partition, up to 8 partitions.

```
Read as: F0 E9 01 3F 00 19 (64 bytes)
```

Each 10-byte partition record:

| Offset | Name | Description |
|--------|------|-------------|
| +0 | Area | Area bitmask for this partition |
| +1 | Unknown | Observed as `0x07` on configured partitions |
| +2 | Unknown | Observed as `0x07` on configured partitions |
| +3..+5 | Unknown | Observed as `0x00` |
| +6 | Unknown | Observed as `0x06` on configured partitions |
| +7..+9 | Unknown | Observed as `0x00` |

Example:
```
Partition 1: 01 07 07 00 00 00 06 00 00 00 → Area 1
Partition 2: 02 07 07 00 00 00 06 00 00 00 → Area 2
Partition 3: 04 00 00 00 00 00 00 00 00 00 → Area 3 (minimal config)
Partition 4: (all zeros = unconfigured)
```

> **Note**: Bytes 1-2 were previously assumed to be entry/exit timers
> but a separate timer register (section 10.5) stores the actual timer
> values. The purpose of bytes 1-2 and 6 in this register is unknown.

### 10.5 Timers (0x016F-0x0188)

26 bytes of system timers for all 8 partitions.

```
Read as: F0 6F 01 1A 00 7A (26 bytes)
```

| Offset | Size | Description |
|--------|------|-------------|
| +0..+15 | 16B | Entry/exit timers: 2 bytes per partition (entry, exit), 8 partitions |
| +16..+23 | 8B | Siren duration: 1 byte per partition |
| +24..+25 | 3B | Unknown (observed: `0x05 0x03 0x03`) |

Timer values are direct byte values in seconds.

Example from a KYO32M:
```
Data: 1E 1E 1E 1E 1E 1E 1E 1E 1E 1E 1E 1E 1E 1E 1E 1E 02 02 02 02 02 02 02 02 05 03 03

P1: entry=30s, exit=30s, siren=2
P2: entry=30s, exit=30s, siren=2
P3: entry=30s, exit=30s, siren=2
P4-P8: entry=30s, exit=30s, siren=2 (defaults)
Trailing bytes: 05 03 03 (unknown)
```

### 10.6 Code Names (0x3000-0x317F)

384 bytes total: 16 ASCII bytes per code name, 24 codes (1-24), space-padded.

```
Address range: 0x3000 - 0x317F
Read as:       F0 00 30 3F 00 5F (codes 1-4)
               F0 40 30 3F 00 9F (codes 5-8)
               F0 80 30 3F 00 DF (codes 9-12)
               F0 C0 30 3F 00 1F (codes 13-16)
               F0 00 31 3F 00 60 (codes 17-20)
               F0 40 31 3F 00 A0 (codes 21-24)
```

Default names: `Code 1          `, `Code 2          `, `Code 3          `, etc.
The first two codes may have custom default names depending on panel firmware.

### 10.7 Digital Key Names (0x3180-0x327F)

256 bytes total: 16 ASCII bytes per key name, 16 keys, space-padded.

```
Address range: 0x3180 - 0x327F
Read as:       F0 80 31 3F 00 E0 (keys 1-4)
               F0 C0 31 3F 00 20 (keys 5-8)
               F0 00 32 3F 00 61 (keys 9-12)
               F0 40 32 3F 00 A1 (keys 13-16)
```

Default names: `Digital Key 1   `, `Digital Key 2   `, etc.

### 10.8 Output Names (0x3280-0x337F)

256 bytes total: 16 ASCII bytes per output name, 16 outputs, space-padded.

```
Address range: 0x3280 - 0x337F
Read as:       F0 80 32 3F 00 E1 (outputs 1-4)
               F0 C0 32 3F 00 21 (outputs 5-8)
               F0 00 33 3F 00 62 (outputs 9-12)
               F0 40 33 3F 00 A2 (outputs 13-16)
```

Default names: `Output 1        `, `Output 2        `, etc.

### 10.9 Phone Number Names (0x3380-0x347F)

128 bytes total: 16 ASCII bytes per number name, 8 ARC phone numbers,
space-padded.

```
Address range: 0x3380 - 0x347F
Read as:       F0 80 33 3F 00 E2 (numbers 1-4)
               F0 C0 33 3F 00 22 (numbers 5-8)
```

Default names: `Number 1        `, `Number 2        `, etc.

### 10.10 Partition Names (0x2BA0-0x2C1F)

128 bytes total: 16 ASCII bytes per partition name, 8 partitions,
space-padded.

```
Address range: 0x2BA0 - 0x2C1F
Read as:       F0 A0 2B 3F 00 FA (partitions 1-4)
               F0 E0 2B 3F 00 3A (partitions 5-8)
```

Default names: `Partition 01    `, `Partition 02    `, etc.

### 10.11 Keypad Names (0x2C20-0x2C9F)

128 bytes total: 16 ASCII bytes per keypad name, 8 keypads, space-padded.

```
Address range: 0x2C20 - 0x2C9F
Read as:       F0 20 2C 3F 00 7B (keypads 1-4)
               F0 60 2C 3F 00 BB (keypads 5-8)
```

Default names: `Keypad 01       `, `Keypad 02       `, etc.

### 10.12 Reader Names (0x2CA0-0x2D9F)

256 bytes total: 16 ASCII bytes per reader name, 16 readers, space-padded.

```
Address range: 0x2CA0 - 0x2D9F
Read as:       F0 A0 2C 3F 00 FB (readers 1-4)
               F0 E0 2C 3F 00 3B (readers 5-8)
               F0 20 2D 3F 00 7C (readers 9-12)
               F0 60 2D 3F 00 BC (readers 13-16)
```

Default names: `Reader 01       `, `Reader 02       `, etc.

### 10.13 Expander Names (0x2DA0-0x2DFF)

96 bytes total: 16 ASCII bytes per name, 4 input expanders + 2 output
expanders.

```
Address range: 0x2DA0 - 0x2DFF
Read as:       F0 A0 2D 3F 00 FC (input expanders 1-4, 64 bytes)
               F0 E0 2D 1F 00 1C (output expanders 1-2, 32 bytes)
```

Default names: `Expander In 01  `, `Expander Out 01 `, etc.

### 10.14 Keyfob ESN Storage (0xC0B1-0xC0DE)

48 bytes total: 3 bytes per keyfob, 16 keyfob slots.

```
Address range: 0xC0B1 - 0xC0DE (3-byte stride)
Read as:       F0 B1 C0 02 00 63 (keyfob 1)
               F0 B4 C0 02 00 66 (keyfob 2)
               ... (address increments by 3 for each keyfob)
               F0 DE C0 02 00 90 (keyfob 16)
```

Each read returns 3 data bytes: the keyfob's ESN. Unenrolled slots
return `00 00 00`.

> **EEPROM timing**: See section 10.16 for critical timing requirements.

### 10.15 Zone ESN Storage (0xC045-0xC0A4)

96 bytes total: 3 bytes per zone, 32 zone slots.

```
Address range: 0xC045 - 0xC0A4 (3-byte stride)
Read as:       F0 45 C0 02 00 F7 (zone 1)
               F0 48 C0 02 00 FA (zone 2)
               ... (address increments by 3 for each zone)
               F0 A2 C0 02 00 54 (zone 32)
```

Each read returns 3 data bytes: the wireless zone sensor's ESN.
Unenrolled or wired zones return `00 00 00`.

> **Note**: This is the only wireless-ESN storage the component reads. The
> `0x019E` window was previously described as a second enrollment table with a
> different format; it is not enrollment data at all, but the user access codes
> (10.3).

> **EEPROM timing**: See section 10.16 for critical timing requirements.

### 10.16 EEPROM Register Timing (0xC0xx range)

Registers in the `0xC0xx` address range (zone ESN at `0xC045` and keyfob
ESN at `0xC0B1`) access the panel's EEPROM/flash storage. Unlike RAM
registers which respond in ~100ms, EEPROM reads take **~1 second** per
request.

**Key implementation requirements**:

- **Timeout**: Use at least 1500ms timeout for 0xC0xx reads. The standard
  250-300ms timeout used for RAM registers will fail silently (no response
  bytes received).
- **Per-slot reads**: Each ESN must be read individually (3 bytes per read,
  `LEN=0x02`). Bulk reads across multiple ESN slots are not supported.
- **Non-blocking**: Reading all 32 zones + 16 keyfobs takes ~48 seconds
  (48 reads × ~1s each). This **must** be spread across multiple polling
  cycles (one read per cycle) to avoid blocking the main loop. Blocking
  for 48+ seconds will cause WiFi/API disconnections and ESPHome safe_mode
  rollback on OTA-flashed devices.
- **Inter-command spacing**: USB captures of KyoUnit show ~1 second between
  consecutive 0xC0xx reads, suggesting the panel needs recovery time between
  EEPROM accesses.

This timing behavior was discovered by comparing USB captures of KyoUnit
(which successfully reads these registers) against ESP32 attempts that
failed with the standard 300ms timeout. The captures show KyoUnit receiving
responses after ~0.5-1 second per EEPROM read.

### 10.17 Panel Options (0x02DB)

5 bytes of panel configuration options.

```
Read as: F0 DB 02 04 00 D1 (4 bytes requested, 5 data bytes returned)
```

Observed response: `60 81 00 1E 00`.

This register contains panel option flags, including option 29
("Disallow tone check"), mapped with high confidence to bit 5 of a
runtime option byte accessed through:

```
Runtime read:  F0 DB 02 00 00 CD
Runtime write: 0F DB 02 00 00 EC VV VV
```

Observed toggle values are `0x40 <-> 0x60` (bit 5 flip). In controlled
tests, enabling/disabling this bit matched the expected trouble behavior
for tone-check scenarios.

The full meaning of other bits in the options block is still not fully
decoded.

### 10.18 Event Routing (0x03D0-0x0921)

Approximately 1362 bytes of Contact ID event routing configuration.
Each event is encoded as 3 bytes.

> **Note**: This address range can be both read (`F0`) and written
> (`0F`). In observed sessions, this range appears as raw `0F` block
> writes during configuration download. The `F0` read forms listed below
> follow the same framing/address pattern and checksum rules.

```
Address range: 0x03D0 - 0x0921
Read as:       F0 D0 03 3F 00 02 (first 64 bytes)
               F0 10 04 3F 00 43 (next 64 bytes)
               F0 50 04 3F 00 83
               F0 90 04 3F 00 C3
               F0 D0 04 3F 00 03
               F0 10 05 3F 00 44
               F0 50 05 3F 00 84
               F0 90 05 3F 00 C4
               F0 D0 05 3F 00 04
               F0 10 06 3F 00 45
               F0 50 06 3F 00 85
               F0 90 06 3F 00 C5
               F0 D0 06 3F 00 05
               F0 10 07 3F 00 46
               F0 50 07 3F 00 86
               F0 90 07 3F 00 C6
               F0 D0 07 3F 00 06
               F0 10 08 3F 00 47
               F0 50 08 3F 00 87
               F0 90 08 3F 00 C7
               F0 D0 08 3F 00 07
               F0 10 09 11 00 1A (final 17 bytes)
```

Each 3-byte event record:

| Offset | Name | Description |
|--------|------|-------------|
| +0 | Event code | Contact ID event code (`0x00`=partition alarm, `0x3A`=zone burglar, etc.) |
| +1 | Phone mask | Bitmask of ARC phone numbers to notify (bit 0=number 1, etc.) |
| +2 | Unknown | Always `0x00` in observed data |

Events are organized in groups:
- **Partition events** (8 per event type): one record per partition.
  Example: partition alarm for P1-P3 enabled = `00 01 00` × 3, then
  `00 00 00` × 5 for P4-P8.
- **Zone events** (32 per event type): one record per zone. Example:
  zone burglar for zones 1-11 enabled = `3A 01 00` × 11, then
  `3A 00 00` × 21 for zones 12-32.

When no events are configured (factory default), the entire region
reads as all zeros.

Observed write profile:
- Full range was written in raw blocks (`0x03D0` through `0x0910`).
- Reassembled payload is `454` records x `3` bytes.
- The phone-mask byte (`+1`) was `0x00` in `450/454` records and non-zero
  in `4/454` records.

This indicates Contact ID delivery was effectively disabled for nearly all
event records in that configuration profile (only a small residual set
remained enabled).

### 10.19 ARC Subscriber Code (0x1509)

4-byte ASCII subscriber code for ARC (Alarm Receiving Centre) reporting.

```
Read as: F0 09 15 04 00 12 (4 bytes)
```

Example response: `30 30 30 30` = ASCII "0000" (default subscriber code).

### 10.20 Panel Mode (0x01E6-0x01E8)

3 bytes of panel status/mode information.

```
Read as: F0 E6 01 02 00 D9
```

Observed response: `11 10 FF`. Exact bit mapping TBD.

### 10.21 Keyfob Button Config (0x011F-0x016E)

80 bytes total: 5 bytes per keyfob slot, 16 slots.

```
Read as:       F0 1F 01 3F 00 4F (keyfobs 1-13, 64 bytes)
               F0 5F 01 0F 00 5F (keyfobs 14-16, 16 bytes)
```

Each 5-byte record contains keyfob button assignment data. Unenrolled
slots contain `00 00 00 00 FF`.

### 10.22 Status Flags (0x1503-0x1508)

6 bytes of system status flags.

```
Read as: F0 03 15 05 00 0D
```

Observed response: `FF FF FF FF FF FF`. Exact bit mapping TBD.

### 10.23 Code Configuration (0x0229-0x02D7)

175 bytes total: configuration and permissions for up to 24 user codes.

```
Address range: 0x0229 - 0x02D7
Read as:       F0 29 02 3F 00 5A (codes 1-9, 64 bytes)
               F0 69 02 3F 00 9A (codes 10-18, 64 bytes)
               F0 A9 02 2F 00 CA (codes 19-24, 47 bytes)
```

Each code record contains partition access permissions, arm mode restrictions,
and other flags. The exact per-byte layout is not fully decoded.

> **Note**: This register stores code **permissions**, not the actual PIN
> digits. PIN values are likely stored in a protected area not readable
> via the serial protocol.

### 10.24 ARC Phone Numbers (0x02F8-0x03CF)

216 bytes total: phone number digits and dialing configuration for up to
8 ARC (Alarm Receiving Centre) phone numbers.

```
Address range: 0x02F8 - 0x03CF
Read as:       F0 F8 02 3F 00 29 (64 bytes)
               F0 38 03 3F 00 6A (64 bytes)
               F0 78 03 3F 00 AA (64 bytes)
               F0 B8 03 17 00 C2 (24 bytes)
```

Phone digits are stored as ASCII bytes (`0x30`-`0x39`), padded with `0xFF`
for unused digit positions. Each number supports up to 16 digits.

Example from first block:
```
3N 3N 3N 3N 3N 3N 3N 3N 3N FF FF FF FF FF FF FF ...
= "NNNNNNNNN" (phone number 1, 9 digits, FF-padded to 16)
```

Following the phone digits, a 4-digit ARC subscriber/client code is
stored as ASCII (4 bytes), followed by configuration flags (`0x0F 0x00`
observed) and `0xFF` padding.

> **Note**: Phone number **names** are stored separately at `0x3380`
> (section 10.9). This register contains the actual dialing digits,
> subscriber code, and call configuration.

### 10.25 Event Log (0x0D27-0x1426)

> **Reverse-engineered from observed sessions**: Two complete sweeps of
> this address range were observed; data changed between sweeps,
> confirming this is live event storage.

1792 bytes of historical event records stored as a circular (ring)
buffer. With a 7-byte record size, the buffer holds 256 slots
(1792 / 7 = 256). Some slots may be empty (all-zero or contain
a sentinel value such as `0x8E` in byte 0).

```
Address range: 0x0D27 - 0x1426
Read as:       F0 27 0D 3F 00 63 (64 bytes)
               F0 67 0D 3F 00 A3 (64 bytes)
               F0 A7 0D 3F 00 E3 (64 bytes)
               F0 E7 0D 3F 00 23 (64 bytes)
               ... (continues in 0x40-byte strides)
               F0 A7 13 3F 00 E9 (64 bytes)
               F0 E7 13 3F 00 29 (64 bytes)
```

Total: 28 reads of 64 bytes = 1792 bytes. Each read uses `LEN=0x3F`
and addresses step by `0x40`.

After each full 28-read sweep, the following control sequence was observed:
`0F E7 14 00 00 0A 00 00` then `3C 03 00 00 00 3F`.
These appear to be session-control/finalization commands.

Each event record is 7 bytes:

| Offset | Size | Description |
|--------|------|-------------|
| +0 | 1B | Event code high byte |
| +1 | 1B | Event code low byte |
| +2 | 1B | Day of month (1-31) |
| +3 | 1B | Month (1-12) |
| +4 | 1B | Year offset from 2000 (e.g., `0x1A` = 2026) |
| +5 | 1B | Hour (0-23) |
| +6 | 1B | Minute (0-59) |

Bytes 0-1 form a **16-bit event code** that encodes both the event
type and the entity number (zone, partition, or user code). The
entity number is an offset from a base code:
`event_code = base + (entity_number - 1)`.

#### Confirmed event type codes

Mapped by correlating raw capture data with KyoUnit 5.5 event log
display (same session, 2026-03-01). Verified across 256+ events.

| Base Code | Entity Offset | Event Type | Max |
|-----------|--------------|------------|-----|
| `0x0000` | + (partition - 1) | Alarm Partition | 8 |
| `0x0008` | + (zone - 1) | Alarm Zone | 32 |
| `0x0078` | + (code - 1) | Recognized Code | 24 |
| `0x0130` | + (partition - 1) | Arm Partition | 8 |
| `0x0138` | + (partition - 1) | Disarm Partition | 8 |
| `0x0140` | + (partition - 1) | Special Arming Partition | 8 |
| `0x0148` | + (partition - 1) | Special Disarming Partition | 8 |
| `0x0150` | + (partition - 1) | Reset Memory Partition | 8 |
| `0x0188` | + (zone - 1) | Restore Zone | 32 |
| `0x01BC` | (none) | Remote Command | — |

Unmapped code ranges (need controlled captures to identify):

| Code Range | Likely Event Type |
|------------|-------------------|
| `0x0028`–`0x0077` | Tamper zone/partition, zone bypass |
| `0x0090`–`0x012F` | Supervision loss, battery, AC mains |
| `0x0158`–`0x0187` | Partition-level events (entry/exit delay) |
| `0x01A8`–`0x01BB` | System events |
| `0x0800`+ | System/maintenance (observed `0x083F` once) |

**Example** (decoded records from address `0x0D27`):

```
01 30  1B 02 1A 09 37   → 0x0130 = Arm Partition n.1,     27-Feb-2026 09:55
01 31  1B 02 1A 09 37   → 0x0131 = Arm Partition n.2,     27-Feb-2026 09:55
01 32  1B 02 1A 09 37   → 0x0132 = Arm Partition n.3,     27-Feb-2026 09:55
00 08  1B 02 1A 09 37   → 0x0008 = Alarm Zone n.1,        27-Feb-2026 09:55
00 00  1B 02 1A 09 37   → 0x0000 = Alarm Partition n.1,   27-Feb-2026 09:55
01 BC  1B 02 1A 09 38   → 0x01BC = Remote Command,        27-Feb-2026 09:56
01 41  1B 02 1A 09 38   → 0x0141 = Spec. Arming Part. n.2,27-Feb-2026 09:56
01 42  1B 02 1A 09 38   → 0x0142 = Spec. Arming Part. n.3,27-Feb-2026 09:56
01 48  1B 02 1A 09 38   → 0x0148 = Spec. Disarm. Part. n.1,27-Feb-2026 09:56
```

**Ring-buffer behavior**: The buffer wraps around. In the observed
sessions, the last block (`0x13E7`) contains older timestamps
(e.g., 26-Feb-2026 23:46, 27-Feb-2026 06:41) followed by newer
entries (up to 01-Mar-2026 11:29 in sweep 1 and 01-Mar-2026 11:36 in sweep 2), confirming circular overwrite.
The write pointer position is not stored in an obvious separate
register — it must be inferred from timestamp ordering.

> **Status**: Record boundaries and timestamp fields (bytes 2-6)
> are confirmed from observed data. Bytes 0-1 (event type/source)
> are not yet mapped to specific Contact ID codes or panel events.
> Fully decoding these would require triggering known events (arm,
> disarm, alarm, tamper, restore) and correlating the raw byte
> values.

### 10.26 EEPROM Control Registers (0xC001, 0xC004)

These registers are in the EEPROM address range but are **not** part
of the zone ESN (0xC045) or keyfob ESN (0xC0B1) storage.

```
0xC001: Read 2 bytes → observed response: FF FF FF FD
0xC004: Read 0 bytes → observed response: 7F
```

Purpose unknown. May be EEPROM management/status registers used by
KyoUnit during upload/download operations. Subject to the same
~1 second EEPROM timing constraints (section 10.16).

### 10.27 Register Address Summary

| Address | Size | Content | Implemented |
|---------|------|---------|-------------|
| `0x0000` | 12B | Firmware version string (ASCII) | Yes |
| `0x009F` | 128B | Zone configuration (32 × 4 bytes) — `0x00A5` on KYO32G, see 10.29 | Yes |
| `0x011F` | 80B | Keyfob button config (16 × 5 bytes) | No |
| `0x016F` | 26B | Timers (entry/exit/siren, 8 partitions) | Yes |
| `0x019E` | 72B | **User access codes** (3 bytes/slot, BCD) — `0x01B4` on KYO32G, see 10.3 | No — masked by `memory_scan` |
| `0x0193` | 1B | Unknown post-write control | No |
| `0x0197` | 1B | Unknown post-write control | No |
| `0x01E6` | 3B | Panel mode/status | No |
| `0x01E9` | 64B | Partition configuration (8 × 10 bytes) | Yes |
| `0x0229` | 175B | Code configuration/permissions (24 codes) | No |
| `0x02DB` | 5B | Panel options | No |
| `0x02F8` | 216B | ARC phone numbers (digits + config) | No |
| `0x03D0` | ~1362B | Event routing (Contact ID) | No |
| `0x0D27` | ~1792B | Event log (256 slots × 7B, circular buffer) | Yes |
| `0xF004` | 11B | Sensor status (realtime) | Yes |
| `0xF008` | ? | Unknown status register | No |
| `0x1503` | 6B | System status flags | No |
| `0x1509` | 4B | ARC subscriber code (ASCII) | No |
| `0x14EA` | 1B | Unknown (near partition status) | No |
| `0x14E7` | 1B | Unknown session control (seen after event-log sweep) | No |
| `0x14EC` | 19B | Partition status (KYO32 non-G) | Yes |
| `0x1560` | 31B | Unknown extended status/config | No |
| `0x2BA0` | 128B | Partition names (8 × 16 bytes ASCII) | Yes |
| `0x2C20` | 128B | Keypad names (8 × 16 bytes ASCII) | No |
| `0x2CA0` | 256B | Reader names (16 × 16 bytes ASCII) | No |
| `0x2DA0` | 96B | Expander names (6 × 16 bytes ASCII) | No |
| `0x2E00` | 512B | Zone names (32 × 16 bytes ASCII) | Yes |
| `0x3000` | 384B | Code names (24 × 16 bytes ASCII) | Yes |
| `0x3180` | 256B | Digital key names (16 × 16 bytes ASCII) | Yes |
| `0x3280` | 256B | Output names (16 × 16 bytes ASCII) | Yes |
| `0x3380` | 128B | Phone number names (8 × 16 bytes ASCII) | No |
| `0xC001` | 2B | EEPROM control/status | No |
| `0xC004` | ? | EEPROM control/status | No |
| `0xC045` | 96B | Zone ESN storage (32 × 3 bytes) | Yes |
| `0xC0B1` | 48B | Keyfob ESN storage (16 × 3 bytes) | Yes |

### 10.28 KYO32G 2.13 Configuration Map (full-scan reference)

First complete scan of a KYO32G's configuration space (firmware `KYO32G  2.13`),
captured with the `memory_scan` debug button. Sections 10.1-10.27 above describe
the KYO32/KYO32M (non-G); the differences below apply to the G and were all
cross-checked against the live entities the component publishes.

**Active configuration** (read correctly by the component's KYO32G path):

| Content | KYO32G address (observed) | Notes |
|---------|---------------------------|-------|
| Zone config | `0x00A5` / `0x00E5` (32 × 4) | **Six bytes later than the non-G base** — see 10.29. Record layout matches 10.1 |
| Timers | `0x016F` | All eight areas' entry/exit + siren, areas 5-8 included and correct |
| Partition names | `0x1750` (8 × 16) | |
| Zone names | zones 17-32 observed at `0x1AB0`-`0x1BAF`; the 1-16 table precedes it (~`0x19B0`) | |
| Code names | `0x1BB0` (24 × 16) | |
| Keyfob / digital-key names | `0x1D30` (16 × 16) | |
| Output names | `0x1E30` (16 × 16) | |
| Zone ESN | `0xC045`+ | |
| Keyfob ESN | `0xC0B1`+ | |

These active name tables differ from the non-G addresses in 10.2 / 10.6-10.13
(`0x2Exx` / `0x3xxx`). On the G those non-G addresses instead fall inside a
built-in string ROM (below), so the component uses model-specific bases.

**Built-in string ROM `0x2BA0`-`0x3820`.** Holds the panel's default entity
labels (`Reader NN`, `Zone N`, `User Code N`, `Key/Card N`, `Output N`,
`Telephone numb.N`) followed by the full UI menu/option string set (language
menu, `PROGRAMMING`, `Ready`, `Times`, `Codes`, `Instant`/`Delayed`/`Path`,
`NC`/`NO`/`BAL`/`DBAL`/`Cycles`, weekday abbreviations, trouble names, …). It is
distinct from the active, user-editable name tables above, which carry the
panel's localized defaults (e.g. Italian `Zona N`). A zero-config read of the
non-G name addresses lands in this ROM, which is why it returns clean English
labels rather than the configured names.

**Two register mismappings on the G** (gated off for `KYO_32G` in
`read_panel_mode_` / `read_status_flags_`):

| Register | Non-G meaning | On KYO32G 2.13 | Effect if read |
|----------|---------------|----------------|----------------|
| `0x01E6` | Panel mode | Inside the access-code table, which on the G runs to `0x01FE` (10.3) | Permanent false `programming=YES`, and the two bytes read are code digits — the read is skipped on KYO32G and KYO8W |
| `0x1503` | Status flags | `FF` padding just after partition status `0x14EC`/`0x1502` (reads `00 00 FF 00 FF`) | Permanent false `trouble=YES` |

The correct KYO32G panel-mode / trouble registers, if they exist, cannot be
located with a programming-mode differential: on KYO32G — exactly as observed
on KYO8 2.04 — entering the installer menu silences the serial bus entirely,
so programming mode is only observable as a communication loss (the
communication-status sensor). Real faults still surface through the
`WARNING_*` binary sensors parsed from the live status poll, so gating these two
reads loses no genuine fault detection.

### 10.29 KYO32G Zone Configuration Offset (0x00A5-0x0124)

The zone table has the same 4-byte record layout as 10.1, but on KYO32G 2.13 it
starts **six bytes later** than the non-G base:

```
Address range: 0x00A5 - 0x0124
Read as:       F0 A5 00 3F 00 D4 (zones 1-16, 64 bytes)
               F0 E5 00 3F 00 14 (zones 17-32, 64 bytes)
```

`0x00A5 + 64 = 0x00E5`, so the two blocks stay contiguous and all 16 records fit
inside each read. Reading the shifted base is what the component does, rather
than skipping a header inside the response like the KYO8 path in 9.2 — skipping
six of the 64 returned data bytes would push the last two records of each block
past the buffer.

Read at the non-G base, every field lands one field early: `zone N area` is in
fact zone N-1's type byte, which is how the shift was first noticed (changing one
zone's type from the keypad moved the *next* zone's reported area).

**Structural confirmation.** 10.1 documents `0x0F` as the last byte of every
record. With base `0x009F` that byte falls on `0x00A2`/`0x00A6`/`0x00AA`, which
all read `0x00`; with base `0x00A5` it lands at offset +3 on all 32 zones.

**Zone type** — the low three bits of byte +0 index the eight type strings in the
panel's string ROM at `0x34B1`, in ROM order:

| Value | Type | | Value | Type |
|-------|------|-|-------|------|
| `0` | Instant | | `4` | Duress |
| `1` | Delayed | | `5` | Fire |
| `2` | Path | | `6` | Switch |
| `3` | 24 Hours | | `7` | Arm Only |

Bit 4 carries the wiring/balance group, as on KYO8 (9.2), so the whole byte must
not be compared against the three-value non-G table — `0x10` is a balanced
Instant zone, not an unknown type.

> **Verification** (KYO32G 2.13, live hardware): one zone was changed from the
> keypad and the block re-read. Instant kept `0x?0`, Duress produced `0x?4`,
> 24 Hours produced `0x?3` — matching ROM order, with no other byte in the block
> moving. The decoded types for all 14 named zones then matched the panel's own
> zone list read from the keypad, and the decoded areas matched two independent
> keypad readings (zone 9 → area 1, zone 15 → area 2).

The non-G base is *not* wrong: 10.1 pins the record layout on a KYO32M using the
same controlled-change method. The two firmware generations genuinely place the
table at different addresses, so the component routes by model and only `KYO_32G`
uses `0x00A5`. Whether KYO8W follows the G or the non-G here is untested — it
currently uses the non-G base.

---

## 11. Known Issues and Unmapped Data

> Note: Many items from the original "known issues" list have been resolved
> by the configuration register map in section 10. The remaining open items
> are listed below.

### 11.1 OC Output Readback on Non-G

Partition status `Rx[12]` always reads `0xFF` on KYO32 non-G. The actual
register holding output state is unknown. Activate and deactivate commands
work correctly -- only readback is affected.

### 11.2 Unmapped Status Bits

- **Rx[14] bit 7** (warning flags): Always observed as 0, purpose unknown.
  Candidate for "T" trouble indicator.
- **Rx[16] bits 0-1** (tamper flags): Always observed as 0, purpose unknown.
  Also candidates for trouble indicator.

### 11.3 "T" Trouble Indicator

The keypad displays a "T" symbol during arm/disarm operations despite no
zone triggers. This is likely an ARC (Alarm Receiving Centre) communications
failure indicator — possibly triggered by a failed phone line tone check
(panel option "29 - Disallow tone check", section 10.17). Controlled
toggle testing identified option 29 with high confidence as bit 5 of the
runtime `0x02DB` byte (`0x40 <-> 0x60`).

What remains unknown is the mapping of the other option bits in the same register block.

### 11.4 Event Routing Format

The event routing register at `0x03D0` (section 10.18) has been partially
decoded: 3 bytes per event with event code, phone mask, and an unknown
byte. The full list of Contact ID event codes and the complete event
ordering within the register are not yet documented. A comprehensive
mapping would require configuring individual events in KyoUnit and
observing the register changes.

### 11.5 Rx[11] in Partition Status

In the KYO32 partition status response, `Rx[11]` is read but not mapped
to any known function. Its purpose is unknown.

### 11.6 Rx[10] Non-Siren Bits

Only bit 5 of `Rx[10]` (partition status) is mapped (siren state). The
other 7 bits in this byte are not decoded and may contain additional
system state flags.

### 11.7 Status Register 0xF008

KyoUnit reads `0xF008` with length 0 (response: unknown). This register
is adjacent to the sensor status register (`0xF004`) and may contain
extended real-time status bits. Purpose and response format TBD.

### 11.8 Extended Partition Data (0x14EA, 0x1560)

- `0x14EA` (1 byte): read just before partition status `0x14EC`. May
  contain a partition status version counter or communication sequence
  number.
- `0x1560` (31 bytes): larger block of unknown data. Could contain
  extended partition configuration or status information not available
  in the standard partition status response.
- `0x14EC` with `len=0x03`: KyoUnit sometimes reads only 3 bytes from
  the partition status register instead of the full 18 bytes. This may
  be a quick status check (e.g., checking only arm/disarm state bits).

### 11.9 Event Log Record Format

The event log at `0x0D27` (section 10.25) uses 7-byte records with
a confirmed timestamp layout in bytes 2-6 (day, month, year, hour,
minute). The meaning of bytes 0-1 is still unknown — they likely
encode the event type and source (zone/partition number or Contact ID
code), but a full mapping requires triggering known events and
correlating the values. Value `0x8E` in byte 0 may mark empty or
deleted slots.

### 11.10 Validation Limits for Local UI Actions

Actions initiated locally from keypad/keyfob (arm/disarm/mode selection)
do not always appear as uniquely identifiable serial write commands.
Some steps are therefore inferred from event-log and status deltas rather than from direct command signatures.

---

## 12. Worked Examples

### 12.1 Read Sensor Status

```
TX:  F0 04 F0 0A 00 EE
RX:  F0 04 F0 0A 00 EE  00 00 00 02 00 00 00 00 00 00 00 02

Echo: F0 04 F0 0A 00 EE
Data: 00 00 00 02  00 00 00 00  00  00  00  02
      |---------|  |---------|  |   |   |   |
      Zone stat    Zone tamper  |   |   |   Checksum
      Z25-32=0     T25-32=0     |   |   Tamper flags=0x00
      Z17-24=0     T17-24=0     |   Area alarm=0x00
      Z9-16=0      T9-16=0      |   Warning flags=0x00
      Z1-8=0x02    T1-8=0x00

Zone status 0x02 at Rx[9]: bit 1 set -> Zone 2 is active (open/triggered).
```

### 12.2 Arm Partition 1 Totally

```
TX:  0F 00 F0 03 00 02 01 00 00 FE FF

0F       = Write command
00 F0    = Arm/disarm function
03       = Arm sub-command
00       = Reserved
02       = Payload length
01       = Total arm mask: bit 0 set = partition 1
00       = Partial arm mask: none
00       = Padding
FE       = CRC: sum(cmd[0..8]) = 0x0F+0x00+0xF0+0x03+0x00+0x02+0x01+0x00+0x00
         = 0x105; CRC = 0x203 - 0x105 = 0xFE (truncated to 8 bits)
FF       = Trailer
```

### 12.3 Exclude Zone 3

```
TX:  0F 01 F0 07 00 07 00 00 00 04 00 00 00 00 04

0F 01 F0 = Write to include/exclude function
07       = Sub-command
00       = Reserved
07       = Payload length

Exclude mask (bytes 6-9):
  [6] Z25-32 = 0x00
  [7] Z17-24 = 0x00
  [8] Z9-16  = 0x00
  [9] Z1-8   = 0x04  (bit 2 set = zone 3)

Include mask (bytes 10-13):
  All 0x00

[14] Checksum = 0x04 (matches the non-zero mask byte)
```

---

## 13. Raw Command Reference Table

| Name | Hex Bytes | Direction | Description |
|------|-----------|-----------|-------------|
| Get Software Version | `F0 00 00 0B 00 FB` | Read | 12-char firmware ID string |
| Get Sensor Status | `F0 04 F0 0A 00 EE` | Read | Zone state + tamper + warnings |
| Get Partition (32G) | `F0 02 15 12 00 19` | Read | Arm state, bypass, alarm/tamper memory |
| Get Partition (32) | `F0 EC 14 12 00 02` | Read | Same, non-G register address |
| Get Partition (8) | `F0 68 0E 09 00 6F` | Read | Same, KYO8/4 register address |
| Arm Partition | `0F 00 F0 03 00 02 TT PP 00 CC FF` | Write | TT=total mask, PP=partial mask |
| Disarm Partition | `0F 00 F0 03 00 02 TT PP 00 CC FF` | Write | Same structure, different masks |
| Reset Alarms | `0F 05 F0 01 00 05 FF 00 FF` | Write | Clear all alarm memory |
| Activate Output | `0F 06 F0 01 00 06 MM 00 MM` | Write | MM=activate bitmask |
| Deactivate Output | `0F 06 F0 01 00 06 00 MM MM` | Write | MM=deactivate bitmask |
| Panel Option Runtime Read | `F0 DB 02 00 00 CD` | Read | Read 1-byte runtime options value |
| Panel Option Runtime Write | `0F DB 02 00 00 EC VV VV` | Write | Write runtime options byte (`VV`) |
| Post-Write Control A | `0F 97 01 00 00 A7 08 08` | Write | Control/barrier after some write phases |
| Post-Write Control B | `0F 93 01 01 00 A4 FF FF FE` | Write | Control/barrier after routing write phase |
| Event Log Session Control | `0F E7 14 00 00 0A 00 00` | Write | Control observed after full event-log sweep |
| Session Barrier | `3C 03 00 00 00 3F` | Control | Non-`F0`/`0F` barrier/finalization command |
| Update DateTime | `0F 03 F0 05 00 07 DD MM YY HH mm SS CC` | Write | Date/time components + checksum |
| Include Zone | `0F 01 F0 07 00 07 00 00 00 00 B4 B3 B2 B1 CC` | Write | B1-B4=include zone bitmasks |
| Exclude Zone | `0F 01 F0 07 00 07 B4 B3 B2 B1 00 00 00 00 CC` | Write | B1-B4=exclude zone bitmasks |
